
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.core.window import Window
from pathlib import Path
import subprocess
import threading

ROOT = Path.home() / "AnimeForge"

KV = """
BoxLayout:
    orientation: "vertical"
    padding: 20
    spacing: 15

    canvas.before:
        Color:
            rgba: 0.07, 0.06, 0.13, 1
        Rectangle:
            pos: self.pos
            size: self.size

    Label:
        text: "[b]ANIMEFORGE AI[/b]"
        markup: True
        font_size: "28sp"
        color: 0.75, 0.65, 1, 1
        size_hint_y: 0.2

    Label:
        text: "Your offline anime studio"
        color: 1, 1, 1, 1

    TextInput:
        id: anime_title
        hint_text: "Enter your anime title"
        multiline: False
        size_hint_y: 0.12

    Button:
        text: "GENERATE ANIME"
        size_hint_y: 0.15
        background_color: 0.45, 0.25, 0.75, 1
        on_release: app.generate()

    Label:
        id: status
        text: "Ready to create"
        color: 1, 1, 1, 1

    Button:
        text: "Open Episode Folder"
        size_hint_y: 0.12
        on_release: app.open_output()
"""


class AnimeForgeApp(App):

    def build(self):
        self.title = "AnimeForge AI"
        Window.clearcolor = (0.07, 0.06, 0.13, 1)
        return Builder.load_string(KV)

    def generate(self):
        title = self.root.ids.anime_title.text.strip()

        if not title:
            self.root.ids.status.text = "Enter a title first"
            return

        self.root.ids.status.text = "Starting production..."

        def task():
            try:
                subprocess.run(
                    ["python", str(ROOT / "animeforge.py")],
                    input="1\n" + title + "\n",
                    text=True,
                    timeout=None,
                    check=True
                )

                self.root.ids.status.text = "Production completed"

            except Exception as error:
                self.root.ids.status.text = str(error)

        threading.Thread(
            target=task,
            daemon=True
        ).start()

    def open_output(self):
        folder = ROOT / "output" / "episodes"
        self.root.ids.status.text = str(folder)


if __name__ == "__main__":
    AnimeForgeApp().run()
