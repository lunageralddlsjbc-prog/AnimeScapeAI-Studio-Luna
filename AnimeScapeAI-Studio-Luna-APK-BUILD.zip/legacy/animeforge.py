
import os
import json
import subprocess
import textwrap
import shutil
from datetime import datetime
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path.home() / "AnimeForge"

MODELS = ROOT / "models"
PROJECTS = ROOT / "projects"
OUTPUT = ROOT / "output"
BIN = ROOT / "bin"

for folder in [
    MODELS / "llm",
    MODELS / "anime",
    MODELS / "interpolation",
    PROJECTS,
    OUTPUT / "episodes",
    OUTPUT / "thumbnails",
]:
    folder.mkdir(parents=True, exist_ok=True)


def run(command):
    subprocess.run(command, check=True)


def generate_story(title, folder):
    model = MODELS / "llm" / "story.gguf"
    cli = BIN / "llama-cli"

    prompt = f"""
You are a professional Japanese anime screenwriter.

Create an original anime series called: {title}

Write:
1. An original premise.
2. Five main characters.
3. Their personalities and appearances.
4. The world and setting.
5. A coherent 12-episode first season.
6. A detailed 24-minute pilot episode.
7. Scene descriptions and dialogue.
8. An emotional ending and continuation hook.

Use original characters and stories.
Maintain consistent character descriptions.
Write dialogue in English.
"""

    if cli.exists() and model.exists():
        result = subprocess.run(
            [
                str(cli),
                "-m", str(model),
                "-p", prompt,
                "-n", "2500",
                "-c", "4096",
                "--temp", "0.7",
            ],
            capture_output=True,
            text=True,
            check=True,
        )

        story = result.stdout

    else:
        story = f"""
ANIME SERIES: {title}

PREMISE:
An unexpected event changes the world of {title}.
A young protagonist discovers a hidden truth
and must confront a powerful mystery.

MAIN CHARACTERS:
Aiko - A courageous young heroine.
Ren - A loyal friend with a mysterious past.
Mika - An intelligent strategist.
Kaito - A rival with hidden motivations.
Yuna - A guardian of ancient knowledge.

PILOT:
The story begins in a peaceful world.
A mysterious event interrupts everyday life.
The characters discover an ancient secret.
Their journey begins.

NOTE:
Install llama.cpp and story.gguf to enable
local AI-generated screenplays.
"""

    (folder / "story.txt").write_text(
        story, encoding="utf-8"
    )

    return story


def generate_storyboard(title, folder):
    shots = []

    for i in range(1, 25):
        shots.append({
            "scene": i,
            "duration_seconds": 60,
            "description": (
                f"Japanese anime scene {i} "
                f"from {title}"
            ),
            "visual_prompt": (
                f"Japanese anime illustration, "
                f"consistent characters, cinematic "
                f"composition, scene {i}, {title}"
            )
        })

    (folder / "storyboard.json").write_text(
        json.dumps(shots, indent=2),
        encoding="utf-8"
    )

    return shots


def generate_character_sheet(folder):
    characters = [
        {
            "name": "Aiko",
            "hair": "Long dark hair",
            "eyes": "Blue",
            "clothing": "White and blue uniform"
        },
        {
            "name": "Ren",
            "hair": "Short black hair",
            "eyes": "Brown",
            "clothing": "Dark jacket"
        }
    ]

    for character in characters:
        name = character["name"].lower()

        path = folder / f"character_{name}.json"

        path.write_text(
            json.dumps(character, indent=2),
            encoding="utf-8"
        )

    return characters


def generate_subtitles(folder):
    lines = []

    for i in range(24):
        start = i * 60
        end = start + 8

        start_time = (
            f"00:{start // 60:02d}:"
            f"{start % 60:02d},000"
        )

        end_time = (
            f"00:{end // 60:02d}:"
            f"{end % 60:02d},000"
        )

        lines.append(
            f"{i + 1}\n"
            f"{start_time} --> {end_time}\n"
            f"Scene {i + 1}: "
            f"The journey continues.\n"
        )

    subtitle_file = folder / "english.srt"

    subtitle_file.write_text(
        "\n".join(lines),
        encoding="utf-8"
    )

    return subtitle_file


def create_scene_cards(title, folder, shots):
    image_dir = folder / "keyframes"
    image_dir.mkdir(exist_ok=True)

    font = ImageFont.load_default()

    for shot in shots:
        image = Image.new(
            "RGB",
            (1280, 720),
            (22, 20, 48)
        )

        draw = ImageDraw.Draw(image)

        draw.text(
            (60, 70),
            "ANIMEFORGE AI",
            fill=(180, 160, 255),
            font=font
        )

        draw.text(
            (60, 300),
            title,
            fill="white",
            font=font
        )

        draw.text(
            (60, 370),
            f"SCENE {shot['scene']}",
            fill=(255, 210, 130),
            font=font
        )

        draw.text(
            (60, 440),
            shot["description"],
            fill="white",
            font=font
        )

        image.save(
            image_dir /
            f"scene_{shot['scene']:02d}.jpg",
            quality=88
        )


def assemble_episode(title, folder):
    ffmpeg = shutil.which("ffmpeg")

    if not ffmpeg:
        raise RuntimeError("FFmpeg is not installed.")

    image_dir = folder / "keyframes"

    concat_file = folder / "concat.txt"

    with concat_file.open("w", encoding="utf-8") as f:
        for i in range(1, 25):
            image = (
                image_dir /
                f"scene_{i:02d}.jpg"
            )

            f.write(
                f"file '{image}'\n"
                f"duration 60\n"
            )

        last = image_dir / "scene_24.jpg"
        f.write(f"file '{last}'\n")

    raw_video = folder / "episode_raw.mp4"

    run([
        ffmpeg,
        "-y",
        "-f", "concat",
        "-safe", "0",
        "-i", str(concat_file),
        "-vf", "fps=24,scale=1280:720",
        "-c:v", "libx264",
        "-preset", "ultrafast",
        "-pix_fmt", "yuv420p",
        "-t", "1440",
        str(raw_video)
    ])

    final_video = (
        OUTPUT / "episodes" /
        f"{folder.name}.mp4"
    )

    subtitle = folder / "english.srt"

    run([
        ffmpeg,
        "-y",
        "-i", str(raw_video),
        "-vf",
        f"subtitles={subtitle}:"
        "force_style='FontSize=22,"
        "PrimaryColour=&H00FFFFFF,"
        "OutlineColour=&H00000000,"
        "Outline=2'",
        "-c:v", "libx264",
        "-preset", "ultrafast",
        "-pix_fmt", "yuv420p",
        "-c:a", "aac",
        "-an",
        str(final_video)
    ])

    return final_video


def create_project():
    title = input("\nAnime title: ").strip()

    if not title:
        print("A title is required.")
        return

    project_id = datetime.now().strftime(
        "%Y%m%d_%H%M%S"
    )

    folder = PROJECTS / project_id
    folder.mkdir(parents=True)

    print("\n[1/6] Generating story...")
    story = generate_story(title, folder)

    print("[2/6] Creating storyboard...")
    shots = generate_storyboard(title, folder)

    print("[3/6] Creating character records...")
    generate_character_sheet(folder)

    print("[4/6] Generating English subtitles...")
    generate_subtitles(folder)

    print("[5/6] Creating scene assets...")
    create_scene_cards(title, folder, shots)

    print("[6/6] Assembling 24-minute video...")
    video = assemble_episode(title, folder)

    print("\nPRODUCTION COMPLETED")
    print("Project:", folder)
    print("Episode:", video)


def main():
    while True:
        print("\n" + "=" * 45)
        print("          ANIMEFORGE AI")
        print("       OFFLINE PRODUCTION")
        print("=" * 45)

        print("1. Create anime episode")
        print("2. Exit")

        choice = input("\nSelect: ").strip()

        if choice == "1":
            try:
                create_project()
            except Exception as error:
                print("Production error:", error)

        elif choice == "2":
            break


if __name__ == "__main__":
    main()

