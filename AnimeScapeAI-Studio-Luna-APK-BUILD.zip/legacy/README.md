# Preserved original prototype files

These are retained from the uploaded Termux project for reference. The Android build uses the new root-level `main.py` and `buildozer.spec`. The original `animeforge.py` is a Termux prototype and is not directly executable as a standalone Android app yet.
