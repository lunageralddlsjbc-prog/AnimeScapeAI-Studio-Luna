from pathlib import Path


def timestamp(seconds):
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = seconds % 60

    return (
        f"{hours:02}:"
        f"{minutes:02}:"
        f"{secs:06.3f}".replace(".", ",")
    )


def create_srt(dialogues, output):
    lines = []

    for index, item in enumerate(dialogues, 1):

        lines.append(str(index))

        lines.append(
            f"{timestamp(item['start'])} --> "
            f"{timestamp(item['end'])}"
        )

        lines.append(item["text"])
        lines.append("")

    Path(output).write_text(
        "\n".join(lines),
        encoding="utf-8"
    )


dialogues = [
    {
        "start": 2.5,
        "end": 5.2,
        "text": "The moon is disappearing!"
    },
    {
        "start": 5.5,
        "end": 8.0,
        "text": "We must protect the kingdom."
    }
]

if __name__ == "__main__":
    create_srt(
        dialogues,
        "english.srt"
    )

    print("English subtitles generated.")

