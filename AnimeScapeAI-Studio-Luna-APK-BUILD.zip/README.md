# AnimeForge AI — Android APK starter

This repository builds a basic Kivy Android APK with GitHub Actions. The app currently creates and lists anime project records locally.

## Build
1. Upload the contents of this folder to the root of your GitHub repository (not the ZIP as a single file).
2. Commit to the `main` branch.
3. Open **Actions → Build AnimeForge APK** and run the workflow.
4. Download `AnimeForge-AI-debug-APK` from the successful run's Artifacts section and extract the APK.

## Current limitations
This starter APK does **not** yet bundle or run Qwen/llama.cpp, image generation, voice generation, or animation. Those require separate Android-native integration and model packaging/download handling. The GGUF model is intentionally excluded from the APK source archive.
