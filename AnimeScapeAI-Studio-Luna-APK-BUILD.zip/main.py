__version__ = "0.3.0"

import json
from datetime import datetime
from pathlib import Path

from kivy.app import App
from kivy.metrics import dp
from kivy.utils import get_color_from_hex
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, Rectangle


class AnimeForgeApp(App):
    def build(self):
        self.title = "AnimeForge AI"
        self.projects_dir = Path(self.user_data_dir) / "projects"
        self.projects_dir.mkdir(parents=True, exist_ok=True)

        root = BoxLayout(orientation="vertical", padding=dp(18), spacing=dp(12))
        with root.canvas.before:
            Color(*get_color_from_hex("#171329"))
            self.bg = Rectangle(pos=root.pos, size=root.size)
        root.bind(pos=self._update_bg, size=self._update_bg)

        root.add_widget(Label(
            text="[b]ANIMEFORGE AI[/b]\n[size=14sp]Offline anime project studio[/size]",
            markup=True, size_hint_y=None, height=dp(94),
            color=get_color_from_hex("#E9DFFF"), halign="center"
        ))
        root.add_widget(Label(
            text="Start with an anime title. Your project is saved on this device.",
            size_hint_y=None, height=dp(48), color=(1, 1, 1, 1)
        ))
        self.title_input = TextInput(
            hint_text="Enter your anime title", multiline=False,
            size_hint_y=None, height=dp(52), padding=dp(12),
            background_color=get_color_from_hex("#292341"),
            foreground_color=(1, 1, 1, 1), cursor_color=(1, 1, 1, 1)
        )
        root.add_widget(self.title_input)
        create = Button(
            text="CREATE ANIME PROJECT", size_hint_y=None, height=dp(54),
            background_normal="", background_color=get_color_from_hex("#7656C9")
        )
        create.bind(on_release=self.create_project)
        root.add_widget(create)
        self.status = Label(text="Ready", size_hint_y=None, height=dp(42), color=get_color_from_hex("#C9BDF0"))
        root.add_widget(self.status)
        root.add_widget(Label(text="YOUR PROJECTS", size_hint_y=None, height=dp(32), color=get_color_from_hex("#E9DFFF"), bold=True))
        scroll = ScrollView()
        self.project_list = BoxLayout(orientation="vertical", spacing=dp(6), size_hint_y=None)
        self.project_list.bind(minimum_height=self.project_list.setter("height"))
        scroll.add_widget(self.project_list)
        root.add_widget(scroll)
        self.refresh_projects()
        return root

    def _update_bg(self, widget, *_):
        self.bg.pos = widget.pos
        self.bg.size = widget.size

    def create_project(self, *_):
        title = self.title_input.text.strip()
        if not title:
            self.status.text = "Please enter an anime title first."
            return
        project_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        folder = self.projects_dir / project_id
        folder.mkdir(parents=True, exist_ok=True)
        data = {
            "id": project_id, "title": title,
            "visual_style": "Japanese Anime",
            "subtitle_language": "English",
            "planned_episodes": 12,
            "planned_episode_duration_minutes": 24,
            "status": "Project created; generation engines not yet connected",
            "created": datetime.now().isoformat()
        }
        (folder / "project.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        self.title_input.text = ""
        self.status.text = "Created project: " + title
        self.refresh_projects()

    def refresh_projects(self):
        self.project_list.clear_widgets()
        files = sorted(self.projects_dir.glob("*/project.json"), reverse=True)
        if not files:
            self.project_list.add_widget(Label(text="No projects yet. Create your first one above.", size_hint_y=None, height=dp(48), color=(0.85, 0.85, 0.9, 1)))
            return
        for file in files:
            try:
                data = json.loads(file.read_text(encoding="utf-8"))
                title = data.get("title", "Untitled")
            except Exception:
                title = file.parent.name
            self.project_list.add_widget(Label(text=title, size_hint_y=None, height=dp(42), color=(1, 1, 1, 1), halign="left"))


if __name__ == "__main__":
    AnimeForgeApp().run()
