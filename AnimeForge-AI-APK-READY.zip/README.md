# AnimeForge AI — Android APK starter

This repository is prepared for a first Android debug APK build using Kivy + Buildozer and GitHub Actions.

## Build

1. Put these files at the **repository root** (especially `main.py` and `buildozer.spec`).
2. Commit and push to the `main` branch, or run **Actions → Build AnimeForge APK → Run workflow**.
3. Download the `AnimeForge-AI-debug-APK` artifact from the completed workflow.

## Current app scope

This APK starter creates and lists anime project records in the app's private storage. It is a working app shell, not yet the full anime-generation product. The uploaded archive's previous Android screen tried to execute a Termux-only path (`~/AnimeForge`) and launch an external CLI; that does not work inside a standalone APK. The Qwen GGUF model and Android-native llama.cpp integration are deliberately not bundled in this first APK build. They need a separate Android-native integration step.

## Model

Do not commit the large `.gguf` model into the APK or Git repository. Plan to let users import/download it into app-private storage in a later version.
