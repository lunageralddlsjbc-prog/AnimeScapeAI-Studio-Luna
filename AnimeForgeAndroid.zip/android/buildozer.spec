source.include_exts = py,kv,json,png,jpg,srt,txt,wav,ogg
requirements = python3,kivy,pillow
orientation = portrait

title = AnimeForge AI
package.name = animeforge
package.domain = org.animeforge

source.dir = .

version = 1.0


fullscreen = 0

android.permissions = READ_MEDIA_IMAGES,READ_MEDIA_VIDEO

android.api = 35
android.minapi = 26

android.archs = arm64-v8a

[buildozer]

log_level = 2
warn_on_root = 1

