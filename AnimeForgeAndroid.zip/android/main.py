import os
import sys
from pathlib import Path
from threading import Thread

from kivy.app import App
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button


class AnimeForgeApp(App):
    def build(self):
        self.title = "AnimeForge AI"

        layout = BoxLayout(
            orientation="vertical",
            padding=20,
            spacing=15
        )

        layout.add_widget(Label(
            text="[b]ANIMEFORGE AI[/b]\n12-Episode Anime Studio",
            markup=True,
            font_size="25sp",
            size_hint_y=0.25
        ))

        self.title_input = TextInput(
            hint_text="Enter your anime title",
            multiline=False,
            size_hint_y=0.12
        )
        layout.add_widget(self.title_input)

        self.status = Label(
            text="Create your original anime season.",
            size_hint_y=0.35
        )
        layout.add_widget(self.status)

        button = Button(
            text="CREATE ANIME SEASON",
            size_hint_y=0.18
        )
        button.bind(on_press=self.create_season)
        layout.add_widget(button)

        return layout

    def create_season(self, instance):
        title = self.title_input.text.strip()

        if not title:
            self.status.text = "Enter an anime title first."
            return

        instance.disabled = True
        self.status.text = "Starting anime generation..."

        Thread(
            target=self.generate,
            args=(title, instance),
            daemon=True
        ).start()

    def generate(self, title, button):
        try:
            os.environ["ANIMEFORGE_HOME"] = self.user_data_dir

            app_folder = Path(__file__).resolve().parent
            sys.path.insert(0, str(app_folder))

            import animeforge

            result = animeforge.create_season(title)
            message = "Generation finished.\n" + str(result)

        except Exception as error:
            message = "Generation error:\n" + str(error)

        def update_ui(dt):
            self.status.text = message
            button.disabled = False

        Clock.schedule_once(update_ui)

if __name__ == "__main__":
    AnimeForgeApp().run()
