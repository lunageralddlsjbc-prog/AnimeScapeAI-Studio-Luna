[app]
title = AnimeScapeAI Studio
package.name = animscapeai
package.domain = org.animescapeai
source.dir = .
source.include_exts = py,kv,json,png,jpg,jpeg,srt,txt
source.exclude_dirs = .git,.github,__pycache__,.buildozer,bin,dist,legacy
version = 0.1.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0

android.api = 35
android.minapi = 23
android.archs = arm64-v8a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
