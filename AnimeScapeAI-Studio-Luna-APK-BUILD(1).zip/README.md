# AnimeScapeAI Studio — Android APK starter

This repository contains a minimal Kivy Android starter app and a GitHub Actions workflow.

## Build
1. Put all files and folders from this package in the root of your GitHub repository.
2. Commit to the `main` branch.
3. Open **Actions** and run **Build AnimeScapeAI Studio APK**.
4. Download the `AnimeScapeAI-Studio-APK` artifact after a successful run.

The app currently creates and lists local anime project folders. It is an APK starter, not yet the complete offline AI anime-generation engine. Qwen/llama.cpp, image generation, voice, and animation are not integrated yet.
