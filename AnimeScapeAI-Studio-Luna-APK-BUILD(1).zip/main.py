import json
import os
from datetime import datetime
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView

class AnimeForgeApp(App):
    def build(self):
        self.title = "AnimeScapeAI Studio"
        root = BoxLayout(orientation="vertical", padding=16, spacing=12)
        root.add_widget(Label(
            text="[b]AnimeScapeAI Studio[/b]\\nCreate your anime project",
            markup=True, font_size="24sp", size_hint_y=None, height=90
        ))
        self.title_input = TextInput(
            hint_text="Enter your anime title",
            multiline=False, size_hint_y=None, height=52
        )
        root.add_widget(self.title_input)
        create = Button(text="Create Project", size_hint_y=None, height=52)
        create.bind(on_release=self.create_project)
        root.add_widget(create)
        self.status = Label(text="Your projects will be saved on this device.", size_hint_y=None, height=60)
        root.add_widget(self.status)
        self.listing = BoxLayout(orientation="vertical", size_hint_y=None, spacing=6)
        self.listing.bind(minimum_height=self.listing.setter("height"))
        scroll = ScrollView()
        scroll.add_widget(self.listing)
        root.add_widget(scroll)
        self.refresh_projects()
        return root

    def projects_dir(self):
        path = os.path.join(self.user_data_dir, "projects")
        os.makedirs(path, exist_ok=True)
        return path

    def create_project(self, *_):
        title = self.title_input.text.strip()
        if not title:
            self.status.text = "Please enter an anime title first."
            return
        safe = "".join(c for c in title if c.isalnum() or c in (" ", "-", "_")).strip()
        safe = safe.replace(" ", "_") or "Untitled"
        folder = os.path.join(self.projects_dir(), safe)
        os.makedirs(folder, exist_ok=True)
        data = {
            "title": title,
            "created": datetime.now().isoformat(timespec="seconds"),
            "status": "Project created"
        }
        with open(os.path.join(folder, "project.json"), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        self.title_input.text = ""
        self.status.text = "Project created: " + title
        self.refresh_projects()

    def refresh_projects(self):
        self.listing.clear_widgets()
        try:
            names = sorted(os.listdir(self.projects_dir()))
        except OSError:
            names = []
        if not names:
            self.listing.add_widget(Label(text="No projects yet.", size_hint_y=None, height=40))
        for name in names:
            self.listing.add_widget(Label(text="• " + name.replace("_", " "), size_hint_y=None, height=36))

if __name__ == "__main__":
    AnimeForgeApp().run()
