import json
import os
import sys
import uuid
from datetime import datetime
from pathlib import Path
from threading import Thread

from kivy.app import App
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView


class AnimeForgeApp(App):
    def build(self):
        self.title = "AnimeForge AI"

        root = BoxLayout(orientation="vertical", padding=18, spacing=12)

        root.add_widget(Label(
            text="[b]ANIMEFORGE AI[/b]\n12-Episode Anime Studio",
            markup=True, font_size="24sp", size_hint_y=None, height="90dp"
        ))

        self.title_input = TextInput(
            hint_text="Enter your anime title",
            multiline=False, size_hint_y=None, height="52dp"
        )
        root.add_widget(self.title_input)

        self.status = Label(
            text="Create a project and generate its season concept and character profiles.",
            halign="left", valign="top", size_hint_y=None
        )
        self.status.bind(
            texture_size=lambda instance, size: setattr(instance, "height", size[1] + 20)
        )
        scroll = ScrollView()
        scroll.add_widget(self.status)
        root.add_widget(scroll)

        self.create_button = Button(
            text="CREATE ANIME PROJECT",
            size_hint_y=None, height="56dp"
        )
        self.create_button.bind(on_press=self.create_project)
        root.add_widget(self.create_button)

        return root

    def create_project(self, instance):
        title = self.title_input.text.strip()
        if not title:
            self.status.text = "Please enter an anime title first."
            return

        instance.disabled = True
        self.status.text = "Creating your project..."
        Thread(target=self.generate_project, args=(title,), daemon=True).start()

    def generate_project(self, title):
        try:
            os.environ["ANIMEFORGE_HOME"] = self.user_data_dir
            app_folder = Path(__file__).resolve().parent
            if str(app_folder) not in sys.path:
                sys.path.insert(0, str(app_folder))

            import animeforge

            project_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]
            project_folder = Path(self.user_data_dir) / "projects" / project_id
            project_folder.mkdir(parents=True, exist_ok=False)

            story = animeforge.generate_season_story(title, project_folder)
            characters = animeforge.generate_characters(project_folder)

            project_info = {
                "id": project_id,
                "title": title,
                "episodes_planned": 12,
                "status": "Project created; episode video rendering is not included in this Android build.",
                "created": datetime.now().isoformat(timespec="seconds"),
                "story_file": str(project_folder / "story.txt"),
                "characters_file": str(project_folder / "characters.json")
            }
            (project_folder / "project.json").write_text(
                json.dumps(project_info, indent=2, ensure_ascii=False),
                encoding="utf-8"
            )

            message = (
                "PROJECT CREATED SUCCESSFULLY\n\n"
                f"Title: {title}\n"
                f"Characters created: {len(characters)}\n"
                "Season concept: saved\n"
                "Character profiles: saved\n\n"
                f"Project folder:\n{project_folder}\n\n"
                "NOTE: This Android APK creates the project, story concept, "
                "and character profiles. Full episode video rendering and "
                "local GGUF AI inference require additional Android-compatible "
                "components and are not included yet."
            )
        except Exception as error:
            message = f"Project creation failed:\n{type(error).__name__}: {error}"

        def update_ui(dt):
            self.status.text = message
            self.create_button.disabled = False

        Clock.schedule_once(update_ui)

if __name__ == "__main__":
    AnimeForgeApp().run()
