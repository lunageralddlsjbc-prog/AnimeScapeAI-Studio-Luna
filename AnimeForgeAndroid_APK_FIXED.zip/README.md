# AnimeForge AI — Android APK build

## Build using GitHub Actions (recommended)

1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Make sure `.github/workflows/android.yml` is included.
4. Open the repository's **Actions** tab.
5. Select **Build AnimeForge Android APK**.
6. Click **Run workflow** (or push a commit to `main`).
7. Wait for the workflow to finish successfully.
8. Open the completed run and download the `AnimeForge-AI-debug-APK` artifact.
9. Extract the downloaded artifact ZIP to get the `.apk` file.

## Build locally

On a supported Linux environment with Java 17 and Android build dependencies installed:

```bash
python -m pip install buildozer "Cython==0.29.37"
buildozer -v android debug
```

The APK is normally written to `bin/`.

## Current app functionality and limitations

This APK version can create a project, generate/save a season concept using the bundled fallback text, and save five character profiles in Android app-private storage.

It is **not yet a full AI anime video generator**. The original production engine expects an external `llama-cli` executable and GGUF model for local model inference, and FFmpeg for episode video rendering. Those components are not bundled or configured for Android in this build. Episode video generation, voice generation, and animation are therefore not claimed as working.

The APK produced by this workflow is a debug/testing APK, not a signed Play Store release.
