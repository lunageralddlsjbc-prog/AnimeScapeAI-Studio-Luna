#!/usr/bin/env python3

import os
import json
import shutil
import subprocess
import uuid
from datetime import datetime
from pathlib import Path

ROOT = Path(os.environ.get("ANIMEFORGE_HOME", Path(__file__).resolve().parent))
PROJECTS = ROOT / "projects"
OUTPUT = ROOT / "output"
EPISODE_OUTPUT = OUTPUT / "episodes"
MODEL = ROOT / "models" / "llm" / "story.gguf"
LLAMA = ROOT / "bin" / "llama-cli"

EPISODES_PER_SEASON = 12
MINUTES_PER_EPISODE = 24
SCENES_PER_EPISODE = 24
SECONDS_PER_SCENE = 60
EPISODE_SECONDS = MINUTES_PER_EPISODE * 60

for folder in (PROJECTS, EPISODE_OUTPUT):
    folder.mkdir(parents=True, exist_ok=True)


def save_json(path, data):
    path.write_text(
        json.dumps(data, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )


def ask_model(prompt, tokens=1200):
    if not MODEL.is_file():
        return None

    if not LLAMA.is_file():
        return None

    try:
        result = subprocess.run(
            [
                str(LLAMA),
                "-m", str(MODEL),
                "-p", prompt,
                "-n", str(tokens),
                "-c", "4096",
                "--temp", "0.7"
            ],
            capture_output=True,
            text=True,
            timeout=900,
            check=True
        )
        return result.stdout.strip() or None
    except (OSError, subprocess.SubprocessError) as error:
        print("Local AI unavailable:", error)
        return None


def generate_season_story(title, season_folder):
    prompt = f"""
Create an original Japanese anime series titled "{title}".

NO NARRATOR. NO VOICE-OVER.
Tell the story through character conversations,
actions, expressions and events.

Every spoken line must identify its speaker.
Example:
AIKO: We have to leave!
REN: I'm not leaving you!

Include five consistent characters, emotional
conversations, arguments, suspense and battles.
Create a connected 12-episode season.
Write dialogue in English.
"""

    story = ask_model(prompt, 3000)

    if not story:
        story = f"""
ANIME SERIES: {title}

No narrator. All storytelling happens through
character dialogue, actions and expressions.

CHARACTERS:
AIKO: Courageous heroine.
REN: Loyal friend.
MIKA: Intelligent strategist.
KAITO: Mysterious rival.
YUNA: Wise guardian.

SEASON:
Episode 1: The Beginning
Episode 2: The First Mystery
Episode 3: A New Companion
Episode 4: The Hidden Village
Episode 5: The Rival
Episode 6: The Secret
Episode 7: The Journey
Episode 8: The Betrayal
Episode 9: The Enemy
Episode 10: Preparation
Episode 11: The Final Battle
Episode 12: A New Dawn
"""

    (season_folder / "story.txt").write_text(story, encoding="utf-8")
    return story



def generate_episode_story(title, episode_number, season_story):
    prompt = f"""
Write episode {episode_number} of the Japanese anime "{title}".

SERIES STORY:
{season_story[:10000]}

IMPORTANT RULES:
- Absolutely NO narrator.
- NO voice-over narration.
- Every spoken line must identify its character.
- Characters must talk naturally to each other.
- Include emotional conversations, arguments,
  friendships, suspense and exciting battles.
- Put visual directions inside square brackets.
- Visual directions are not spoken dialogue.
- Keep character personalities consistent.
- Write in English.
- Connect this episode to the season story.

Use these sound-effect cues where appropriate:
[SFX: footsteps]
[SFX: punch]
[SFX: sword_clash]
[SFX: whoosh]
[SFX: explosion]
[SFX: magic_blast]
[SFX: impact_heavy]
[SFX: thunder]
[SFX: debris]
[SFX: energy_charge]

Use these music cues:
[MUSIC: battle]
[MUSIC: emotional]
[MUSIC: suspense]
[MUSIC: peaceful]

Write a complete screenplay with multiple scenes,
character dialogue, action and a strong ending.
"""

    story = ask_model(prompt, 1800)

    if not story:
        story = f"""
{title}
EPISODE {episode_number:02d}

SCENE 1 - MYSTERIOUS FOREST

[Wind moves through the trees.]

AIKO: Did you hear that?

REN: Hear what?

AIKO: Something is following us.

[SFX: footsteps]

REN: Stay behind me!

[MUSIC: suspense]

SCENE 2 - THE ATTACK

[An enemy charges toward the heroes.]

[SFX: whoosh]

REN: Aiko, move!

[SFX: punch]

AIKO: I'm not running away!

[SFX: energy_charge]

REN: Then we fight together!

[MUSIC: battle]

SCENE 3 - AFTER THE BATTLE

AIKO: Ren, are you hurt?

REN: I'll be fine. What was that thing?

AIKO: I think this is only the beginning.

[MUSIC: emotional]
"""

    return story



def generate_characters(folder):
    characters = [
        {
            "name": "Aiko",
            "hair": "Long dark hair",
            "eyes": "Blue",
            "clothing": "White and blue uniform",
            "personality": "Courageous and compassionate"
        },
        {
            "name": "Ren",
            "hair": "Short black hair",
            "eyes": "Brown",
            "clothing": "Dark jacket",
            "personality": "Loyal and thoughtful"
        },
        {
            "name": "Mika",
            "hair": "Shoulder-length brown hair",
            "eyes": "Green",
            "clothing": "Light travelling outfit",
            "personality": "Intelligent and strategic"
        },
        {
            "name": "Kaito",
            "hair": "Spiky silver hair",
            "eyes": "Gray",
            "clothing": "Dark combat uniform",
            "personality": "Competitive and guarded"
        },
        {
            "name": "Yuna",
            "hair": "Long violet hair",
            "eyes": "Violet",
            "clothing": "Traditional blue robes",
            "personality": "Wise and mysterious"
        }
    ]

    for character in characters:
        filename = "character_" + character["name"].lower() + ".json"
        save_json(folder / filename, character)

    save_json(folder / "characters.json", characters)
    return characters


def generate_storyboard(title, episode_number, episode_story, folder):
    shots = []

    sentences = [
        line.strip()
        for line in episode_story.splitlines()
        if len(line.strip()) > 15
    ]

    for index in range(SCENES_PER_EPISODE):
        detail = sentences[index % len(sentences)] if sentences else (
            f"The adventure of {title} continues."
        )

        shots.append({
            "scene": index + 1,
            "episode": episode_number,
            "duration_seconds": SECONDS_PER_SCENE,
            "description": detail[:240],
            "visual_prompt": (
                "Japanese anime illustration, original characters, "
                "consistent character design, cinematic composition, "
                + detail[:180]
            )
        })

    save_json(folder / "storyboard.json", shots)
    return shots


def timestamp(seconds):
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    return f"{hours:02d}:{minutes:02d}:{secs:02d},000"


def generate_subtitles(folder, episode_number):
    lines = []

    for index in range(SCENES_PER_EPISODE):
        start = index * SECONDS_PER_SCENE
        end = start + 8

        lines.extend([
            str(index + 1),
            f"{timestamp(start)} --> {timestamp(end)}",
            f"Episode {episode_number}, scene {index + 1}: "
            "The journey continues.",
            ""
        ])

    subtitle_file = folder / "english.srt"
    subtitle_file.write_text("\n".join(lines), encoding="utf-8")
    return subtitle_file


def create_scene_cards(title, episode_number, folder, shots):
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError as error:
        raise RuntimeError(
            "Pillow is missing. Install it with: pip install pillow"
        ) from error

    image_dir = folder / "keyframes"
    image_dir.mkdir(parents=True, exist_ok=True)
    font = ImageFont.load_default()

    for shot in shots:
        image = Image.new(
            "RGB", (1280, 720), (22, 20, 48)
        )
        draw = ImageDraw.Draw(image)

        draw.text(
            (60, 65), "ANIMEFORGE AI",
            fill=(180, 160, 255), font=font
        )
        draw.text(
            (60, 220), title,
            fill="white", font=font
        )
        draw.text(
            (60, 290), f"EPISODE {episode_number:02d} / 12",
            fill=(255, 210, 130), font=font
        )
        draw.text(
            (60, 350), f"SCENE {shot['scene']:02d} / 24",
            fill=(255, 210, 130), font=font
        )

        description = shot["description"]
        draw.text(
            (60, 430), description[:150],
            fill="white", font=font
        )

        image.save(
            image_dir / f"scene_{shot['scene']:02d}.jpg",
            quality=88
        )


def assemble_episode(title, episode_number, folder, season_id):
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError(
            "FFmpeg is missing. Run: pkg install ffmpeg"
        )

    image_dir = folder / "keyframes"
    concat_file = folder / "concat.txt"
    raw_video = folder / "episode_raw.mp4"

    with concat_file.open("w", encoding="utf-8") as file:
        for index in range(1, SCENES_PER_EPISODE + 1):
            image = image_dir / f"scene_{index:02d}.jpg"
            if not image.is_file():
                raise RuntimeError(f"Missing scene image: {image}")

            file.write(f"file '{image.as_posix()}'\n")
            file.write(f"duration {SECONDS_PER_SCENE}\n")

        last_image = image_dir / f"scene_{SCENES_PER_EPISODE:02d}.jpg"
        file.write(f"file '{last_image.as_posix()}'\n")

    subprocess.run(
        [
            ffmpeg, "-y",
            "-f", "concat",
            "-safe", "0",
            "-i", str(concat_file),
            "-t", str(EPISODE_SECONDS),
            "-r", "24",
            "-vf", "scale=1280:720,format=yuv420p",
            "-c:v", "libx264",
            "-preset", "ultrafast",
            "-an",
            str(raw_video)
        ],
        check=True,
        stdout=subprocess.DEVNULL
    )

    final_video = (
        EPISODE_OUTPUT /
        f"{season_id}_episode_{episode_number:02d}.mp4"
    )

    subtitle = folder / "english.srt"

    # Add subtitles when FFmpeg has the subtitles filter.
    filters = subprocess.run(
        [ffmpeg, "-filters"],
        capture_output=True,
        text=True
    )

    if " subtitles " in filters.stdout:
        subtitle_path = str(subtitle).replace("\\", "\\\\").replace(":", "\\:")
        video_filter = (
            f"subtitles='{subtitle_path}':"
            "force_style='FontSize=22,Outline=2'"
        )

        subprocess.run(
            [
                ffmpeg, "-y",
                "-i", str(raw_video),
                "-vf", video_filter,
                "-t", str(EPISODE_SECONDS),
                "-c:v", "libx264",
                "-preset", "ultrafast",
                "-pix_fmt", "yuv420p",
                "-an",
                str(final_video)
            ],
            check=True,
            stdout=subprocess.DEVNULL
        )
    else:
        shutil.copy2(raw_video, final_video)
        print("Subtitle overlay filter unavailable; SRT saved separately.")

    return final_video


def create_season(title):
    if not title.strip():
        raise ValueError("Anime title is required.")

    if not shutil.which("ffmpeg"):
        raise RuntimeError("Install FFmpeg first: pkg install ffmpeg")

    season_id = (
        datetime.now().strftime("%Y%m%d_%H%M%S")
        + "_" + uuid.uuid4().hex[:6]
    )

    season_folder = PROJECTS / season_id
    season_folder.mkdir(parents=True, exist_ok=False)

    season_info = {
        "id": season_id,
        "title": title,
        "episodes": EPISODES_PER_SEASON,
        "duration_minutes_per_episode": MINUTES_PER_EPISODE,
        "total_runtime_minutes": (
            EPISODES_PER_SEASON * MINUTES_PER_EPISODE
        ),
        "created": datetime.now().isoformat(timespec="seconds"),
        "status": "Production started",
        "episode_files": []
    }

    save_json(season_folder / "project.json", season_info)

    print("\nGenerating season story...")
    season_story = generate_season_story(title, season_folder)

    print("Creating shared character records...")
    generate_characters(season_folder)

    completed = 0

    for number in range(1, EPISODES_PER_SEASON + 1):
        print("\n" + "=" * 48)
        print(f"GENERATING EPISODE {number:02d} OF 12")
        print("=" * 48)

        episode_folder = (
            season_folder / f"episode_{number:02d}"
        )
        episode_folder.mkdir(parents=True, exist_ok=True)

        try:
            print("[1/5] Writing episode story...")
            episode_story = generate_episode_story(
                title, number, season_story
            )
            (episode_folder / "story.txt").write_text(
                episode_story, encoding="utf-8"
            )

            print("[2/5] Creating storyboard...")
            shots = generate_storyboard(
                title, number, episode_story, episode_folder
            )

            print("[3/5] Copying character records...")
            for character_file in season_folder.glob("character_*.json"):
                shutil.copy2(
                    character_file,
                    episode_folder / character_file.name
                )

            print("[4/5] Creating English subtitles and scene cards...")
            generate_subtitles(episode_folder, number)
            create_scene_cards(
                title, number, episode_folder, shots
            )

            print("[5/5] Rendering 24-minute episode...")
            video = assemble_episode(
                title, number, episode_folder, season_id
            )

            episode_info = {
                "episode": number,
                "title": title,
                "duration_minutes": MINUTES_PER_EPISODE,
                "duration_seconds": EPISODE_SECONDS,
                "video": str(video),
                "status": "Completed"
            }
            save_json(
                episode_folder / "episode.json", episode_info
            )

            season_info["episode_files"].append(str(video))
            completed += 1
            print("EPISODE COMPLETED:", video)

        except Exception as error:
            print(f"EPISODE {number:02d} FAILED:", error)
            save_json(
                episode_folder / "episode.json",
                {
                    "episode": number,
                    "status": "Failed",
                    "error": str(error)
                }
            )

        season_info["status"] = (
            "Completed" if completed == EPISODES_PER_SEASON
            else f"{completed} of 12 episodes completed"
        )
        save_json(season_folder / "project.json", season_info)

    print("\n" + "=" * 48)
    print("SEASON PRODUCTION FINISHED")
    print("=" * 48)
    print("Anime:", title)
    print("Episodes completed:", completed, "/ 12")
    print("Target runtime per episode: 24 minutes")
    print("Season folder:", season_folder)
    print("Video folder:", EPISODE_OUTPUT)

    if completed != EPISODES_PER_SEASON:
        print("Some episodes failed. Check their episode.json files.")
    else:
        print("All 12 episode videos were created.")


def main():
    while True:
        print("\n" + "=" * 48)
        print("             ANIMEFORGE AI")
        print("          12-EPISODE SEASON")
        print("=" * 48)
        print("1. Create a 12-episode anime season")
        print("2. Exit")

        try:
            choice = input("\nSelect: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nClosing AnimeForge.")
            break

        if choice == "1":
            title = input("\nEnter anime title: ").strip()
            try:
                create_season(title)
            except Exception as error:
                print("Season error:", error)
        elif choice == "2":
            print("Goodbye!")
            break
        else:
            print("Choose 1 or 2.")


if __name__ == "__main__":
    main()
