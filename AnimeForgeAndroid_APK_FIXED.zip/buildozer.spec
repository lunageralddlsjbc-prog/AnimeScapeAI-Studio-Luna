[app]
title = AnimeForge AI
package.name = animeforge
package.domain = org.animeforge
source.dir = .
source.include_exts = py,kv,json,png,jpg,jpeg,srt,txt,wav,ogg
version = 1.0.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0

# Android compatibility
android.api = 35
android.minapi = 26
android.archs = arm64-v8a
android.accept_sdk_license = True

# No broad storage permissions are needed; project files are stored
# in the app-private data directory.

[buildozer]
log_level = 2
warn_on_root = 1
